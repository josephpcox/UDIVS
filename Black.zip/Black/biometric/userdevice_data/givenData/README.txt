This folder contains user-device interaction data from 22 subjects.
Each row represents 
	- time of day (day or night)
	- action that occurred
	- type of action (application launch, bluetooth sighting, or wifi sighting)
	- day of the week (sunday - saturday)

Rows are listed in the actual order that the user executed them.
There are a variable number of rows per subject.